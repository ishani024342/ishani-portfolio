import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Verdant from "./pages/Verdant";
import NomadStay from "./pages/NomadStay";
import PulseFit from "./pages/PulseFit";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/verdant" component={Verdant} />
      <Route path="/nomad-stay" component={NomadStay} />
      <Route path="/pulsefit" component={PulseFit} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
