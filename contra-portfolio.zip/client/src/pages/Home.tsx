/**
 * Home — Portfolio Overview
 * Design: Precision Minimal
 * Clean, editorial layout with oversized typography and generous whitespace
 */
import { Link } from "wouter";
import { ArrowUpRight, Monitor, Hotel, HeartPulse, Sprout } from "lucide-react";
import { motion } from "framer-motion";

const projects = [
  {
    title: "Loam",
    subtitle: "Landing Page Design",
    description:
      "Soil-monitoring startup landing page with a live diagnostic panel hero, moss/clay palette, and Space Grotesk + IBM Plex type system.",
    icon: Sprout,
    color: "#5B7B4F",
    bg: "bg-[#f5f0e8]",
    route: "https://contra.com/ishani_sharma_wnid51kg/work",
    tags: ["Landing Page", "Eco-tech", "Responsive"],
  },
  {
    title: "Verdant",
    subtitle: "Dashboard UI",
    description:
      "Smart indoor garden monitoring dashboard with real-time analytics, plant health metrics, and intuitive environmental controls.",
    icon: Monitor,
    color: "#00c9a7",
    bg: "bg-[#f0faf7]",
    route: "/verdant",
    tags: ["Dashboard", "Analytics", "IoT"],
  },
  {
    title: "Nomad Stay",
    subtitle: "Booking Platform",
    description:
      "Boutique hotel booking platform with editorial design, curated property listings, and a seamless reservation flow.",
    icon: Hotel,
    color: "#1e3a5f",
    bg: "bg-[#f5f0ec]",
    route: "/nomad-stay",
    tags: ["E-commerce", "Hospitality", "UX Design"],
  },
  {
    title: "PulseFit",
    subtitle: "Mobile App Design",
    description:
      "Fitness tracking app with activity rings, workout analytics, and social challenges. Built for engagement and habit formation.",
    icon: HeartPulse,
    color: "#ff4757",
    bg: "bg-[#fef0f2]",
    route: "/pulsefit",
    tags: ["Mobile", "Health", "Gamification"],
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] } },
};

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <img src="/manus-storage/logo-mark_71bdf55f.png" alt="IS" className="w-8 h-8" />
            <span className="font-display font-bold text-lg tracking-tight">Ishani Sharma</span>
          </div>
          <p className="font-mono text-xs text-muted-foreground hidden sm:block">
            Web Designer & Developer · Jaipur, India
          </p>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-24 md:py-32 lg:py-40">
        <div className="container">
          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <p className="font-mono text-sm text-muted-foreground mb-6 tracking-wide uppercase">
              Portfolio
            </p>
            <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[1.05] max-w-4xl">
              Interfaces crafted
              <br />
              <span className="text-muted-foreground">with intention.</span>
            </h1>
            <p className="mt-8 text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed">
              Clean design, purposeful interaction, and pixel-perfect execution.
              Each project is built to solve real problems with elegant solutions.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Divider */}
      <div className="container">
        <div className="border-t border-border/50" />
      </div>

      {/* Projects Grid */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {projects.map((project, i) => {
              const Icon = project.icon;
              return (
                <motion.a
                  key={project.title}
                  href={project.route}
                  target={project.route.startsWith("http") ? "_blank" : undefined}
                  rel={project.route.startsWith("http") ? "noopener noreferrer" : undefined}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    delay: 0.2 + i * 0.1,
                    duration: 0.5,
                    ease: [0.23, 1, 0.32, 1] as [number, number, number, number],
                  }}
                  className="group block"
                >
                  <div className={`${project.bg} rounded-xl p-8 md:p-10 h-full transition-shadow duration-300 hover:shadow-lg hover:shadow-black/5`}>
                    {/* Project Header */}
                    <div className="flex items-start justify-between mb-6">
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${project.color}15` }}
                      >
                        <Icon size={24} style={{ color: project.color }} strokeWidth={1.5} />
                      </div>
                      <ArrowUpRight
                        size={20}
                        className="text-muted-foreground transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-foreground"
                        strokeWidth={1.5}
                      />
                    </div>

                    {/* Title */}
                    <h3 className="font-display text-2xl md:text-3xl font-bold tracking-tight mb-1">
                      {project.title}
                    </h3>
                    <p
                      className="font-mono text-xs tracking-wide uppercase mb-4"
                      style={{ color: project.color }}
                    >
                      {project.subtitle}
                    </p>

                    {/* Description */}
                    <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                      {project.description}
                    </p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 rounded-full text-xs font-medium bg-white/80 border border-border/30 text-muted-foreground"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.a>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border/50">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © 2026 Ishani Sharma. Designed and built with care.
          </p>
          <div className="flex items-center gap-4">
            <a
              href="https://contra.com/ishani_sharma_wnid51kg"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Contra Profile
            </a>
            <span className="text-border">·</span>
            <span className="text-sm text-muted-foreground">Jaipur, India</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
