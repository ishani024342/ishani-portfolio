/**
 * Nomad Stay — Boutique Hotel Booking Platform
 * Design: Precision Minimal with warm ivory + deep navy accent
 * Showcases editorial design, property listings, and booking UX
 */
import { Link } from "wouter";
import { ArrowLeft, Calendar, MapPin, Star, Coffee, Palmtree } from "lucide-react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] },
  }),
};

const properties = [
  {
    name: "Casa del Mar",
    location: "Tulum, Mexico",
    price: "$285",
    rating: 4.9,
    reviews: 127,
    amenities: ["Ocean View", "Pool", "Spa"],
  },
  {
    name: "Alpine Retreat",
    location: "Zermatt, Switzerland",
    price: "$420",
    rating: 4.8,
    reviews: 89,
    amenities: ["Mountain View", "Ski Access", "Fireplace"],
  },
  {
    name: "Ryokan Serenity",
    location: "Kyoto, Japan",
    price: "$310",
    rating: 5.0,
    reviews: 64,
    amenities: ["Onsen", "Garden", "Tea Ceremony"],
  },
];

const features = [
  {
    title: "Curated Properties",
    description:
      "Every listing is hand-selected for design excellence and guest experience. No algorithm noise — just exceptional places to stay.",
    icon: Palmtree,
  },
  {
    title: "Instant Booking",
    description:
      "Streamlined three-step reservation flow. Choose your dates, confirm your stay, receive instant confirmation with digital keys.",
    icon: Calendar,
  },
  {
    title: "Guest Concierge",
    description:
      "Dedicated support before, during, and after your stay. Local recommendations, restaurant reservations, and experience bookings.",
    icon: Coffee,
  },
];

export default function NomadStay() {
  return (
    <div className="min-h-screen bg-[#faf8f5] text-[#1e3a5f]">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-[#faf8f5]/90 backdrop-blur-xl border-b border-[#1e3a5f]/10">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 group">
            <ArrowLeft size={16} className="text-[#1e3a5f]/40 group-hover:text-[#1e3a5f] transition-colors" />
            <span className="font-mono text-xs text-[#1e3a5f]/40 group-hover:text-[#1e3a5f]/70 transition-colors">
              All Projects
            </span>
          </Link>
          <span className="font-mono text-xs text-[#1e3a5f]/20">02 / 04</span>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-20 md:py-28">
        <div className="container">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            custom={0}
            className="max-w-4xl"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-3 h-3 rounded-full bg-[#ff6b4a]" />
              <span className="font-mono text-xs tracking-widest uppercase text-[#ff6b4a]/70">
                Case Study
              </span>
            </div>
            <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]">
              Nomad Stay
              <br />
              <span className="text-[#1e3a5f]/40">Booking Platform</span>
            </h1>
            <p className="mt-8 text-lg text-[#1e3a5f]/60 max-w-2xl leading-relaxed">
              A boutique hotel booking platform designed for discerning travelers.
              Editorial layout meets conversion-optimized UX, creating an experience
              that feels like reading a luxury travel magazine.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Platform Preview */}
      <section className="pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
            className="relative rounded-2xl overflow-hidden bg-white border border-[#1e3a5f]/5 shadow-2xl shadow-[#1e3a5f]/10"
          >
            <img
              src="/manus-storage/nomad-hero_d6a43fd3.png"
              alt="Nomad Stay Booking Platform"
              className="w-full h-auto"
            />
          </motion.div>
        </div>
      </section>

      {/* Property Listings Preview */}
      <section className="py-16 md:py-24">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="font-mono text-xs tracking-widest uppercase text-[#1e3a5f]/30 mb-12"
          >
            Property Cards
          </motion.p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {properties.map((property, i) => (
              <motion.div
                key={property.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.4 }}
                className="bg-white rounded-xl border border-[#1e3a5f]/8 p-6 group hover:shadow-lg hover:shadow-[#1e3a5f]/5 transition-all duration-300"
              >
                {/* Placeholder image area */}
                <div className="aspect-[4/3] rounded-lg bg-gradient-to-br from-[#1e3a5f]/5 to-[#ff6b4a]/5 mb-5 flex items-center justify-center">
                  <Palmtree size={32} className="text-[#1e3a5f]/20" strokeWidth={1} />
                </div>
                <h3 className="font-display text-lg font-bold mb-1">{property.name}</h3>
                <div className="flex items-center gap-1 text-sm text-[#1e3a5f]/50 mb-3">
                  <MapPin size={12} />
                  <span>{property.location}</span>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <span className="font-display text-2xl font-bold">{property.price}</span>
                  <span className="text-xs font-mono text-[#1e3a5f]/50">per night</span>
                </div>
                <div className="flex items-center gap-1 mb-4">
                  <Star size={14} className="fill-[#f4a261] text-[#f4a261]" />
                  <span className="text-sm font-medium">{property.rating}</span>
                  <span className="text-xs text-[#1e3a5f]/40">({property.reviews} reviews)</span>
                </div>
                <button className="w-full py-3 rounded-lg bg-[#ff6b4a] text-white font-medium text-sm hover:bg-[#ff5a38] transition-colors duration-200">
                  Book Now
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="container">
        <div className="border-t border-[#1e3a5f]/8" />
      </div>

      {/* Features */}
      <section className="py-16 md:py-24">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="font-mono text-xs tracking-widest uppercase text-[#1e3a5f]/30 mb-12"
          >
            Design Features
          </motion.p>
          <div className="space-y-12">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15, duration: 0.5 }}
                  className="flex gap-8 items-start"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-[#ff6b4a]/10 flex items-center justify-center">
                    <Icon size={22} className="text-[#ff6b4a]" strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-[#1e3a5f]/50 leading-relaxed max-w-2xl">{feature.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-16 md:py-20">
        <div className="container">
          <div className="border-t border-[#1e3a5f]/8 pt-12">
            <div className="flex flex-wrap gap-3">
              {["React", "TypeScript", "Tailwind CSS", "Framer Motion", "Stripe", "Headless CMS", "Responsive"].map(
                (tech) => (
                  <span
                    key={tech}
                    className="px-4 py-2 rounded-full text-sm border border-[#1e3a5f]/10 text-[#1e3a5f]/50 font-mono"
                  >
                    {tech}
                  </span>
                )
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-[#1e3a5f]/8">
        <div className="container flex items-center justify-between">
          <p className="font-mono text-xs text-[#1e3a5f]/30">Ishani Sharma · 2026</p>
          <Link href="/" className="font-mono text-xs text-[#1e3a5f]/50 hover:text-[#1e3a5f] transition-colors">
            Back to Portfolio
          </Link>
        </div>
      </footer>
    </div>
  );
}
