/**
 * Verdant — Smart Indoor Garden Dashboard
 * Design: Precision Minimal with deep charcoal + emerald accent
 * Showcases data visualization, IoT monitoring UI, and clean card layouts
 */
import { Link } from "wouter";
import { ArrowLeft, Droplets, Thermometer, Sun, Leaf, Zap, Activity } from "lucide-react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] },
  }),
};

const metrics = [
  { label: "Plants Monitored", value: "47", unit: "active", icon: Leaf, color: "#00c9a7" },
  { label: "Avg. Humidity", value: "68", unit: "%", icon: Droplets, color: "#00a896" },
  { label: "Temperature", value: "24", unit: "°C", icon: Thermometer, color: "#48bfe3" },
  { label: "Light Index", value: "92", unit: "/100", icon: Sun, color: "#f4a261" },
];

const features = [
  {
    title: "Real-Time Monitoring",
    description:
      "Continuous environmental tracking with sub-minute refresh rates. Every sensor feeds into an intelligent dashboard that adapts to your garden's needs.",
    icon: Activity,
  },
  {
    title: "Automated Care",
    description:
      "Smart watering schedules, light adjustment timers, and nutrient alerts. The system learns your plants' patterns and optimizes care automatically.",
    icon: Zap,
  },
  {
    title: "Health Diagnostics",
    description:
      "AI-powered plant health analysis using image recognition and sensor fusion. Catch issues before they become visible to the human eye.",
    icon: Leaf,
  },
];

export default function Verdant() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-xl border-b border-white/5">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 group">
            <ArrowLeft size={16} className="text-white/50 group-hover:text-white transition-colors" />
            <span className="font-mono text-xs text-white/50 group-hover:text-white/80 transition-colors">
              All Projects
            </span>
          </Link>
          <span className="font-mono text-xs text-white/30">01 / 04</span>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-20 md:py-28">
        <div className="container">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            custom={0}
            className="max-w-4xl"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-3 h-3 rounded-full bg-[#00c9a7]" />
              <span className="font-mono text-xs tracking-widest uppercase text-[#00c9a7]/70">
                Case Study
              </span>
            </div>
            <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]">
              Verdant
              <br />
              <span className="text-white/40">Dashboard UI</span>
            </h1>
            <p className="mt-8 text-lg text-white/50 max-w-2xl leading-relaxed">
              A comprehensive monitoring dashboard for smart indoor gardens.
              Designed to transform raw sensor data into actionable plant care insights
              through clean visualization and intuitive interaction patterns.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
            className="relative rounded-2xl overflow-hidden bg-[#12121a] border border-white/5 shadow-2xl shadow-black/40"
          >
            <img
              src="/manus-storage/verdant-hero_fc5d62ed.png"
              alt="Verdant Dashboard UI"
              className="w-full h-auto"
            />
          </motion.div>
        </div>
      </section>

      {/* Key Metrics */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {metrics.map((metric, i) => {
              const Icon = metric.icon;
              return (
                <motion.div
                  key={metric.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    delay: i * 0.1,
                    duration: 0.4,
                    ease: [0.23, 1, 0.32, 1] as [number, number, number, number],
                  }}
                  className="bg-[#12121a] border border-white/5 rounded-xl p-6"
                >
                  <Icon size={20} className="mb-4" style={{ color: metric.color }} strokeWidth={1.5} />
                  <p className="font-display text-4xl md:text-5xl font-bold tracking-tight">
                    {metric.value}
                    <span className="text-sm font-normal text-white/30 ml-1">{metric.unit}</span>
                  </p>
                  <p className="mt-2 text-sm text-white/40">{metric.label}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="container">
        <div className="border-t border-white/5" />
      </div>

      {/* Features */}
      <section className="py-16 md:py-24">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="font-mono text-xs tracking-widest uppercase text-white/30 mb-12"
          >
            Key Features
          </motion.p>
          <div className="space-y-12">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15, duration: 0.5 }}
                  className="flex gap-8 items-start"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-[#00c9a7]/10 flex items-center justify-center">
                    <Icon size={22} className="text-[#00c9a7]" strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-white/50 leading-relaxed max-w-2xl">{feature.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-16 md:py-20">
        <div className="container">
          <div className="border-t border-white/5 pt-12">
            <div className="flex flex-wrap gap-3">
              {["React", "TypeScript", "Recharts", "Tailwind CSS", "Framer Motion", "IoT Sensors", "WebSocket"].map(
                (tech) => (
                  <span
                    key={tech}
                    className="px-4 py-2 rounded-full text-sm border border-white/10 text-white/60 font-mono"
                  >
                    {tech}
                  </span>
                )
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-white/5">
        <div className="container flex items-center justify-between">
          <p className="font-mono text-xs text-white/30">Ishani Sharma · 2026</p>
          <Link href="/" className="font-mono text-xs text-white/50 hover:text-white/80 transition-colors">
            Back to Portfolio
          </Link>
        </div>
      </footer>
    </div>
  );
}
