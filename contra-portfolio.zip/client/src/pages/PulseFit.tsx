/**
 * PulseFit — Fitness Tracking Mobile App
 * Design: Precision Minimal with white + electric coral accent
 * Showcases mobile app design, data visualization, and engagement patterns
 */
import { Link } from "wouter";
import { ArrowLeft, Heart, Footprints, Flame, Trophy, Zap, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] },
  }),
};

const stats = [
  { label: "Active Users", value: "24K", icon: TrendingUp, color: "#ff4757" },
  { label: "Workouts Logged", value: "1.2M", icon: Footprints, color: "#ff6b81" },
  { label: "Calories Burned", value: "4.8M", icon: Flame, color: "#ff9f43" },
  { label: "Goals Crushed", value: "89%", icon: Trophy, color: "#2ed573" },
];

const features = [
  {
    title: "Activity Rings",
    description:
      "Three interlocking rings track movement, exercise, and standing. Visual progress that motivates completion and celebrates consistency.",
    icon: Footprints,
  },
  {
    title: "Heart Rate Intelligence",
    description:
      "Continuous heart rate monitoring with zone-based training insights. Know when to push harder and when to recover.",
    icon: Heart,
  },
  {
    title: "Social Challenges",
    description:
      "Weekly leaderboards, friend competitions, and achievement badges. Fitness becomes more engaging when shared with your community.",
    icon: Zap,
  },
];

export default function PulseFit() {
  return (
    <div className="min-h-screen bg-white text-[#2d3436]">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-xl border-b border-black/5">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 group">
            <ArrowLeft size={16} className="text-black/30 group-hover:text-black/70 transition-colors" />
            <span className="font-mono text-xs text-black/30 group-hover:text-black/60 transition-colors">
              All Projects
            </span>
          </Link>
          <span className="font-mono text-xs text-black/15">03 / 04</span>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-20 md:py-28">
        <div className="container">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            custom={0}
            className="max-w-4xl"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-3 h-3 rounded-full bg-[#ff4757]" />
              <span className="font-mono text-xs tracking-widest uppercase text-[#ff4757]/60">
                Case Study
              </span>
            </div>
            <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]">
              PulseFit
              <br />
              <span className="text-black/30">Mobile App Design</span>
            </h1>
            <p className="mt-8 text-lg text-black/50 max-w-2xl leading-relaxed">
              A fitness tracking app that turns daily movement into measurable progress.
              Designed with engagement psychology in mind — every interaction
              reinforces the habit loop that keeps users coming back.
            </p>
          </motion.div>
        </div>
      </section>

      {/* App Preview */}
      <section className="pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
            className="relative rounded-2xl overflow-hidden bg-[#f8f9fa] border border-black/5 shadow-2xl shadow-black/5"
          >
            <img
              src="/manus-storage/pulsefit-hero_2cd2c804.png"
              alt="PulseFit App Design"
              className="w-full h-auto"
            />
          </motion.div>
        </div>
      </section>

      {/* App Screens */}
      <section className="py-16 md:py-24">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="font-mono text-xs tracking-widest uppercase text-black/20 mb-12"
          >
            Screen Designs
          </motion.p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Dashboard Screen */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0, duration: 0.4 }}
              className="bg-white rounded-2xl border border-black/5 p-6 shadow-sm"
            >
              <div className="aspect-[9/16] bg-[#2d3436] rounded-xl p-5 flex flex-col">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <p className="text-white/50 text-xs font-mono">Good Morning</p>
                    <p className="text-white text-lg font-display font-bold">Alex</p>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-[#ff4757] flex items-center justify-center">
                    <span className="text-white text-xs font-bold">A</span>
                  </div>
                </div>
                {/* Activity Ring Placeholder */}
                <div className="flex-1 flex items-center justify-center">
                  <div className="relative w-32 h-32">
                    <div className="absolute inset-0 rounded-full border-4 border-[#ff4757]/20" />
                    <div className="absolute inset-0 rounded-full border-4 border-[#ff4757] border-t-transparent border-r-transparent" style={{ transform: "rotate(45deg)" }} />
                    <div className="absolute inset-3 rounded-full border-4 border-[#ff9f43]/20" />
                    <div className="absolute inset-3 rounded-full border-4 border-[#ff9f43] border-b-transparent border-l-transparent" style={{ transform: "rotate(-30deg)" }} />
                    <div className="absolute inset-6 rounded-full border-4 border-[#2ed573]/20" />
                    <div className="absolute inset-6 rounded-full border-4 border-[#2ed573] border-t-transparent" style={{ transform: "rotate(120deg)" }} />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-4">
                  <div className="text-center">
                    <p className="text-[#ff4757] text-sm font-bold">1,247</p>
                    <p className="text-white/30 text-[10px]">Steps</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[#ff9f43] text-sm font-bold">340</p>
                    <p className="text-white/30 text-[10px]">Cal</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[#2ed573] text-sm font-bold">45</p>
                    <p className="text-white/30 text-[10px]">Min</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Workout Screen */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1, duration: 0.4 }}
              className="bg-white rounded-2xl border border-black/5 p-6 shadow-sm"
            >
              <div className="aspect-[9/16] bg-[#2d3436] rounded-xl p-5 flex flex-col">
                <p className="text-white/50 text-xs font-mono mb-1">Today's Workout</p>
                <p className="text-white text-lg font-display font-bold mb-4">Upper Body</p>
                {[
                  { name: "Bench Press", sets: "4 × 12", status: "done" },
                  { name: "Pull-ups", sets: "3 × 10", status: "active" },
                  { name: "Shoulder Press", sets: "3 × 12", status: "pending" },
                  { name: "Tricep Dips", sets: "3 × 15", status: "pending" },
                ].map((exercise) => (
                  <div
                    key={exercise.name}
                    className={`flex items-center justify-between py-3 border-b border-white/5 ${
                      exercise.status === "done" ? "opacity-50" : ""
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-5 h-5 rounded-full border-2 ${
                          exercise.status === "done"
                            ? "border-[#2ed573] bg-[#2ed573]"
                            : exercise.status === "active"
                            ? "border-[#ff4757]"
                            : "border-white/20"
                        }`}
                      >
                        {exercise.status === "done" && (
                          <div className="w-full h-full flex items-center justify-center">
                            <div className="w-2 h-0.5 bg-white rounded" style={{ transform: "rotate(45deg)" }} />
                          </div>
                        )}
                        {exercise.status === "active" && <div className="w-1.5 h-1.5 bg-[#ff4757] rounded-full m-auto" />}
                      </div>
                      <span className="text-white text-sm">{exercise.name}</span>
                    </div>
                    <span className="text-white/40 text-xs font-mono">{exercise.sets}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Progress Screen */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className="bg-white rounded-2xl border border-black/5 p-6 shadow-sm"
            >
              <div className="aspect-[9/16] bg-[#2d3436] rounded-xl p-5 flex flex-col">
                <p className="text-white/50 text-xs font-mono mb-1">Weekly Progress</p>
                <p className="text-white text-lg font-display font-bold mb-4">This Week</p>
                {/* Bar chart placeholder */}
                <div className="flex-1 flex items-end justify-between gap-2 px-2">
                  {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => {
                    const heights = [60, 80, 45, 90, 70, 40, 55];
                    return (
                      <div key={i} className="flex-1 flex flex-col items-center gap-2">
                        <div
                          className="w-full rounded-sm bg-[#ff4757]"
                          style={{ height: `${heights[i]}%`, opacity: heights[i] / 100 }}
                        />
                        <span className="text-white/30 text-[10px]">{day}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-4 p-3 rounded-lg bg-white/5 border border-white/5">
                  <div className="flex items-center justify-between">
                    <span className="text-white/50 text-xs">Weekly Goal</span>
                    <span className="text-[#ff4757] text-xs font-bold">85%</span>
                  </div>
                  <div className="mt-2 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full w-[85%] bg-[#ff4757] rounded-full" />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="container">
        <div className="border-t border-black/5" />
      </div>

      {/* Features */}
      <section className="py-16 md:py-24">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="font-mono text-xs tracking-widest uppercase text-black/20 mb-12"
          >
            Design Features
          </motion.p>
          <div className="space-y-12">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15, duration: 0.5 }}
                  className="flex gap-8 items-start"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-[#ff4757]/10 flex items-center justify-center">
                    <Icon size={22} className="text-[#ff4757]" strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="font-display text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-black/50 leading-relaxed max-w-2xl">{feature.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 md:py-20">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.4 }}
                  className="text-center"
                >
                  <Icon size={20} className="mx-auto mb-3" style={{ color: stat.color }} strokeWidth={1.5} />
                  <p className="font-display text-3xl md:text-4xl font-bold">{stat.value}</p>
                  <p className="mt-1 text-sm text-black/40">{stat.label}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-12 border-t border-black/5">
        <div className="container">
          <div className="flex flex-wrap gap-3">
            {["React Native", "TypeScript", "Firebase", "Lottie", "Framer Motion", "HealthKit", "Dark Mode"].map(
              (tech) => (
                <span
                  key={tech}
                  className="px-4 py-2 rounded-full text-sm border border-black/8 text-black/40 font-mono"
                >
                  {tech}
                </span>
              )
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-black/5">
        <div className="container flex items-center justify-between">
          <p className="font-mono text-xs text-black/25">Ishani Sharma · 2026</p>
          <Link href="/" className="font-mono text-xs text-black/40 hover:text-black/70 transition-colors">
            Back to Portfolio
          </Link>
        </div>
      </footer>
    </div>
  );
}
